<?php
/**
 * Plugin Name:       Call Me
 * Plugin URI:        https://it-gorod.com.ua
 * Description:       Shortcode - [call]
 * Version:           1.0
 * Author:            Igor Kalabaev
 * Author URI:        https://it-gorod.com.ua
 * License:           GPLv3
 * License URI:       http://www.gnu.org
 * Text Domain:       Call Me
 * Domain Path:       /lang

 */
 
 defined ('ABSPATH') or die();
 //Активация плагина и создание таблицы в db call_me
register_activation_hook( __FILE__, 'create_plugin_tables' );
function create_plugin_tables(){
 global $wpdb;
 $table_call = $wpdb->prefix . 'call_me';
 $sql = "CREATE TABLE $table_call (
 id int(11) NOT NULL AUTO_INCREMENT,
 name varchar(255) DEFAULT NULL,
 email varchar(255) DEFAULT NULL,
 phone varchar(255) DEFAULT NULL,
 date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY id (id)
 );";
 require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
 dbDelta( $sql );
}

//Удаление плагина и удаление таблицы в db call_me
register_uninstall_hook( __FILE__, 'drop_plugin_tables');
function drop_plugin_tables()
{
 global $wpdb;
 $wpdb->query( 'DROP TABLE IF EXISTS ' . $wpdb->prefix . 'call_me' );
}
 
 //Создаем форму и шорткод [call]
add_shortcode( 'call', 'short' );
function short( $args ){
	return '
  <form method="post" action="">
    <div>
      <label for="name">Name</label><br>
      <input type="text" name="name" required>
    </div>
    <div>
      <label for="email">E-mail</label><br>
      <input type="email" name="email" required>
    </div>
	<div>
      <label for="tel">Phone</label><br>
      <input type="tel" name="phone" required>
    </div>
	<br>
    <button type="submit" name="contact-form">Call me</button> 
  </form>';
}

//Передаем данные в db
function theme_form_init() {
    if( ! isset($_POST['contact-form']) ) return false;
    global $wpdb;
    $args = array(
        'name'     => isset($_POST['name']) ? esc_attr( trim($_POST['name']) ) : '',
		'email'     => isset($_POST['email']) ? esc_attr( trim($_POST['email']) ) : '',
		'phone'     => isset($_POST['phone']) ? esc_attr( trim($_POST['phone']) ) : '',
    );
    $result = $wpdb->insert( $wpdb->prefix . 'call_me', $args );
	header ("Location: ".$_SERVER['HTTP_REFERER']);
}
add_action('wp', 'theme_form_init');

//Создаем в админке пункт меню "Call Me"
add_action( 'admin_menu', 'true_top_menu_page', 25 );

function true_top_menu_page(){
 
	add_menu_page(
		'Seting Call me',
		'Call me',
		'manage_options',
		'true_call_me',
		'get_by_name',
		'dashicons-phone',
		90
	);
}
 
 //Страница админки
function get_by_name( $name )
{
 global $wpdb;
 $table_call = $wpdb->prefix . 'call_me';
 $results = $wpdb->get_results( $wpdb->prepare('SELECT * FROM '.$table_call) );
 echo'
 <h3>Заявки обратного звонка</h3><hr>
  <table align="left" style="width:100%">
    <thead align="left">
      <tr>
        <th>ID</th>
        <th>Name</th>
		<th>Email</th>
		<th>Phone</th>
		<th>Data-time</th>
      </tr>
    </thead>
  <tbody>';
 foreach($results as $row){
	echo '<tr><td>' .$row->id.' </td>';
	echo '<td>' .$row->name.' </td>';
	echo '<td>' .$row->email.' </td>';
	echo '<td>' .$row->phone.' </td>';
	echo '<td>' .$row->date.' </td></tr>';
   }   
 echo '</tbody>
  </table>
  <button style="position:absolute;top:15px;right:15px" type="submit">Delete</button>';
}